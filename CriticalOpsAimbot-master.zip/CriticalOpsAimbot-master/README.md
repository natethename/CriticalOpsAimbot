# Critical Ops Aimbot
#### @hackedbyshmoo

An aimbot for Critical Ops v0.9.18. I'm already bored of it so here you guys go. Have fun trying to compile it :] For educational purposes only. Keep the spirit of hacking alive!
